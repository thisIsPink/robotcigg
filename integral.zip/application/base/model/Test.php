<?php
namespace app\base\model;

use think\Exception;

class Test extends Base
{

}

