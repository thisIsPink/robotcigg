<?php
namespace app\base\controller;

class ModelCode
{
    static public $uid_list = [

    ];
}