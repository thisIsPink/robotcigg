<?php
namespace app\index\controller;

use think\Controller;

class Index extends Controller
{
    private function isLogin()
    {
        if(session('user')==null){
            return $this->index();
        }else{
            return true;
        }
    }
    public function index()
    {
        if(session('user')){
            return $this->fetch();
        }else{
            return $this->fetch('login');
        }
    }
    public function welcome(){
        if($this->isLogin()){
            $id=session('user');
            $userInfo=db('user')->where('uid',$id)->field('inv,user,name,phone,status,integral,money')->find();
            $invInfo=db('user')->where('uid',substr($userInfo['inv'],-1))->field('user,name,phone,status')->find();
            $this->assign('dtime',time());
            $this->assign('invInfo',$invInfo);
            $this->assign('userInfo',$userInfo);
            return $this->fetch();
        }
    }
    public function _empty($name)
    {
        if($this->isLogin()){
            return $this->fetch($name);
        }
    }

}
