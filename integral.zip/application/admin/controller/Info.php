<?php
namespace app\admin\controller;

class Info extends Base
{
    protected $returnValue=['code','data','msg'];
    protected function setData($data=[],$num){
        return $this->layuiReturnCode($data,$num);
    }
    public function memberInfo(){
        $paramData=$this->buildParam(['page'=>'page','limit'=>'limit']);
        $data=db('user')->order('uid','desc')->where('status','1,2')->page($paramData['page'],$paramData['limit'])->select();
        $num=db('user')->where('status','1,2')->count();
        echo json_encode($this->setData($data,$num));
    }
    public function memberExamine(){
        $paramData=$this->buildParam(['page'=>'page','limit'=>'limit']);
        $data=db('user')->alias('u')->join('inviation i','i.user=u.uid')->join('user u1','i.source=u1.uid')->order('u.uid','desc')->where('u.status','3')->field('u.uid,u1.user source,u.user,u.name,u.phone')->page($paramData['page'],$paramData['limit'])->select();
        $num=db('user')->where('status','3')->count();
        echo json_encode($this->setData($data,$num));
    }
    public function settlement(){
        $data=db('user')->order('uid','desc')->field('uid,user,name,phone,integral,inv')->cursor();
        $users=[];
        foreach ($data as $value){
//            var_dump($value);
            if(!isset($users[$value['uid']])){
                $users[$value['uid']]=['money'=>0,'down_money'=>0];
            }
            if($value['integral']<100000){
                $money=$value['integral']*0;
            }elseif ($value['integral']<300000){
                $money=bcadd(bcmul($value['integral'],0.04),$users[$value['uid']]['money'],2);
            }elseif ($value['integral']<800000){
                $money=bcadd(bcmul($value['integral'],0.05),$users[$value['uid']]['money'],2);
            }elseif ($value['integral']<2000000){
                $money=bcadd(bcmul($value['integral'],0.06),$users[$value['uid']]['money'],2);
            }elseif ($value['integral']<5000000){
                $money=bcadd(bcmul($value['integral'],0.07),$users[$value['uid']]['money'],2);
            }elseif ($value['integral']<10000000){
                $money=bcadd(bcmul($value['integral'],0.08),$users[$value['uid']]['money'],2);
            }elseif ($value['integral']<20000000){
                $money=bcadd(bcmul($value['integral'],0.09),$users[$value['uid']]['money'],2);
            }else{
                $money=bcadd(bcmul($value['integral'],0.1),$users[$value['uid']]['money'],2);
            }
            $down=explode(',',$value['inv']);
            foreach ($down as $values){
                if(!isset($users[$values])){
                    if($values==0)continue;
                    $users[$values]=['money'=>0,'down_money'=>0];
                }
                $users[$values]['money']=bcsub($users[$values]['money'],$money,2);
                $users[$values]['down_money']=bcadd($users[$values]['down_money'],$money,2);
//                var_dump($users[$values]);
            }
            if(isset($users[$value['uid']['down_money']])){
                $down_money=$users[$value['uid']['down_money']];
            }else{
                $down_money=0;
            }
            $users[$value['uid']]=['user'=>$value['user'],'name'=>$value['name'],'phone'=>$value['phone'],'integral'=>$value['integral'],'down_money'=>$down_money,'money'=>$money];
//            break;
        }
        echo json_encode($this->setData($users,0));
    }
}
?>