<?php
namespace app\common\model;

class User extends Basis
{
    protected $table = 'user';
    protected $pk = 'uid';
    public function add($data){
        if($this->where('user',$data['user'])->find()){
            return [  'code'=> 1002,  'msg' => '用户已存在'];
        }else{
            $id=$this->insertGetId($data);
            if($id) {
                return [  'code'=> 1001, 'data'=>$id, 'msg' => '操作成功'];
            }else{
                return [  'code'=> 1009,  'msg' => '操作失败'];
            }
        }
    }
    public function changeStatus($data){
        $id=$data[$this->pk];
        unset($data[$this->pk]);
        if($this->where('uid',$id)->update($data)){
            return [  'code'=> 1001,  'msg' => '操作成功'];
        }else{
            return [  'code'=> 1009,  'msg' => '操作失败'];
        }
    }
    public function emptyAll(){
        if($this->update(['integral'=>'0'])){
            return [  'code'=> 1001,  'msg' => '操作成功'];
        }else{
            return [  'code'=> 1009,  'msg' => '操作失败'];
        }
    }
}