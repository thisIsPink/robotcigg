<?php

namespace app\common\validate;

use think\Validate;

class User extends Validate
{

    protected $rule = [
        'id'=>'number',
        'user'=>'require|max:40|alphaDash',
        'name'=>'require|max:20',
        'phone'=>'require|mobile',
        'password'=>'require|max:60',
        'integral'=>'require|max:10|number',
        'money'=>'require|float',
        'status'=>'require|number|max:11',
        'inv'=>'require'
    ];

    protected $field = [
        'user'=>'用户名',
        'name'=>'真实姓名',
        'phone'=>'手机号',
        'password'=>'密码',
        'integral'=>'积分',
        'status'=>'状态',
    ];
    protected $scene= [
        'login'=>['user','password'],
        'add'=>['user','name','phone','password','integral','money','status'],
        'valStatus'=>['uid','status']
    ];
}
