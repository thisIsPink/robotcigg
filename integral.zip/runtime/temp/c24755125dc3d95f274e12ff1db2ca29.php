<?php /*a:1:{s:89:"E:\phpStudy\PHPTutorial\WWW\gongsi\integral\application\admin\view\index\member_list.html";i:1564731327;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
    
    <head>
        <meta charset="UTF-8">
        <title>欢迎页面-X-admin2.2</title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
        <link rel="stylesheet" href="/static/xadmin/css/font.css">
        <link rel="stylesheet" href="/static/xadmin/css/xadmin.css">
        <script src="/static/xadmin/lib/layui/layui.js" charset="utf-8"></script>
        <script type="text/javascript" src="/static/xadmin/js/xadmin.js"></script>
    </head>
    
    <body>
        <div class="x-nav">
            <span class="layui-breadcrumb">
                <a href="">首页</a>
                <a href="">演示</a>
                <a>
                    <cite>导航元素</cite></a>
            </span>
            <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" onclick="location.reload()" title="刷新">
                <i class="layui-icon layui-icon-refresh" style="line-height:30px"></i>
            </a>
        </div>
        <div class="layui-fluid">
            <div class="layui-row layui-col-space15">
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-body ">
                            <form class="layui-form layui-col-space5">
                                <div class="layui-inline layui-show-xs-block">
                                    <input class="layui-input" autocomplete="off" placeholder="开始日" name="start" id="start"></div>
                                <div class="layui-inline layui-show-xs-block">
                                    <input class="layui-input" autocomplete="off" placeholder="截止日" name="end" id="end"></div>
                                <div class="layui-inline layui-show-xs-block">
                                    <input type="text" name="username" placeholder="请输入用户名" autocomplete="off" class="layui-input"></div>
                                <div class="layui-inline layui-show-xs-block">
                                    <button class="layui-btn" lay-submit="" lay-filter="sreach">
                                        <i class="layui-icon">&#xe615;</i></button>
                                </div>
                            </form>
                        </div>
                        <div class="layui-card-body ">
                            <table class="layui-table" lay-data="{url:'/admin/info/memberInfo',page:true,toolbar: '#toolbarDemo',id:'test'}" lay-filter="test">
                                <thead>
                                    <tr>
                                        <th lay-data="{field:'uid'}">ID</th>
                                        <th lay-data="{field:'user'}">用户名</th>
                                        <th lay-data="{field:'name'}">真实姓名</th>
                                        <th lay-data="{field:'phone'}">手机</th>
                                        <th lay-data="{field:'integral'}">积分</th>
                                        <th lay-data="{field:'money'}">现金</th>
                                        <th lay-data="{templet:'<div>{{d.status==1?\'正常\':\'冻结\'}}</div>'}">状态</th>
                                        <th lay-data="{toolbar: '#bar'}">操作</th></tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script type="text/html" id="toolbarDemo">
        <div class = "layui-btn-container" >
                <button class="layui-btn" onclick="xadmin.open('添加用户','./member_add.html',500,400)">
                    <i class="layui-icon"></i>添加</button>
        </div > 
    </script>
    <script type="text/html" id="bar">
        <a onclick="member_stop(this,'{{d.uid}}')" href="javascript:;"  title="启用">
            <i class="layui-icon">&#xe601;</i>
        </a>
    </script>
    <script>layui.use('laydate',
        function() {
            var laydate = layui.laydate;

            //执行一个laydate实例
            laydate.render({
                elem: '#start' //指定元素
            });

            //执行一个laydate实例
            laydate.render({
                elem: '#end' //指定元素
            });

        });</script>
    <script>layui.use('table',
        function() {
            var table = layui.table;
        });</script>

</html>