<?php /*a:1:{s:90:"E:\phpStudy\PHPTutorial\WWW\gongsi\integral\application\index\view\index\higher_level.html";i:1564721654;}*/ ?>
<!DOCTYPE html>
<html class="x-admin-sm">
<head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.2</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="stylesheet" href="/static/xadmin/css/font.css">
    <link rel="stylesheet" href="/static/xadmin/css/xadmin.css">
    <script src="/static/xadmin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="./js/xadmin.js"></script>
</head>
<body>
<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header">上级信息</div>
                <div class="layui-card-body ">
                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <th>用户状态</th>
                            <td>已激活</td></tr>
                        <tr>
                            <th>用户名</th>
                            <td>user</td></tr>
                        <tr>
                            <th>用户等级</th>
                            <td>官方代理人</td></tr>
                        <tr>
                            <th>用户姓名</th>
                            <td>路人甲</td></tr>
                        <tr>
                            <th>联系电话</th>
                            <td>177777777</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</body>
</html>